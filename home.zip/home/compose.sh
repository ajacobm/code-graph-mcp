#!/bin/bash

# ============================================================================
# compose.sh - Docker Compose wrapper with internal state management
# ============================================================================

# INTERNAL STATE MANAGEMENT
# State file location: ~/.composesh-state (one per directory)
# Format: COMPOSESH_VAR_NAME=value pairs

_STATE_DIR="${HOME}/.composesh"
_STATE_FILE="${_STATE_DIR}/.state_${PWD//\//_}"  # Hash PWD into filename

# Initialize state directory
[[ ! -d "$_STATE_DIR" ]] && mkdir -p "$_STATE_DIR"

# Normalize variable name to COMPOSESH_* prefix
_normalize_var_name() {
  local var_name="$1"
  
  # If it doesn't start with COMPOSESH_, add the prefix
  if [[ ! "$var_name" =~ ^COMPOSESH_ ]]; then
    var_name="COMPOSESH_${var_name}"
  fi
  
  echo "$var_name"
}

# Load internal state from file (persists across sessions for this directory)
_load_state() {
  [[ -f "$_STATE_FILE" ]] && source "$_STATE_FILE"
}

# Save a single internal var to state file
_save_state_var() {
  local var_name="$1"
  local var_value="${!var_name}"
  
  if [[ -z "$var_value" ]]; then
    # Remove var if empty
    sed -i.bak "/^${var_name}=/d" "$_STATE_FILE" 2>/dev/null
    [[ -f "$_STATE_FILE.bak" ]] && rm "$_STATE_FILE.bak"
  else
    # Update or add var
    if grep -q "^${var_name}=" "$_STATE_FILE" 2>/dev/null; then
      sed -i.bak "s/^${var_name}=.*/${var_name}=${var_value}/" "$_STATE_FILE"
      [[ -f "$_STATE_FILE.bak" ]] && rm "$_STATE_FILE.bak"
    else
      echo "${var_name}=${var_value}" >> "$_STATE_FILE"
    fi
  fi
}

# Set an internal variable and persist it
_set_internal() {
  local var_name="$1"
  local var_value="${2:-}"
  
  # Normalize the variable name to include COMPOSESH_ prefix
  var_name=$(_normalize_var_name "$var_name")
  
  export "$var_name=$var_value"
  _save_state_var "$var_name"
}

# Toggle a boolean internal variable (assumes true/false values)
_toggle_internal() {
  local var_name="$1"
  
  # Normalize the variable name to include COMPOSESH_ prefix
  var_name=$(_normalize_var_name "$var_name")
  
  local current_value="${!var_name:-false}"
  local new_value="false"
  
  [[ "$current_value" == "false" ]] && new_value="true"
  
  _set_internal "$var_name" "$new_value"
  echo "$var_name=$new_value"
}

# Initialize state file with metadata and defaults
_init_state_file() {
  # Only initialize if file doesn't exist
  [[ -f "$_STATE_FILE" ]] && return
  
  # Create header with PWD for identification
  cat > "$_STATE_FILE" << EOF
# compose.sh state file
# PWD: $PWD
# Created: $(date -u +'%Y-%m-%d %H:%M:%S UTC')
# ---
EOF
}

# Show all internal state vars (both set and defaults)
_show_state() {
  _init_state_file
  
  echo "$(_colorize "\033[35m" "Internal state for: $PWD")"
  echo "$(_colorize "\033[35m" "State file: $_STATE_FILE")"
  echo "---"
    
  # Show state file (includes metadata + set vars)
  # cat "$_STATE_FILE"
  
  echo ""
  echo "$(_colorize "\033[34m" "Available Variables & Current Values:")"
  echo "---"
  
  # List all available vars with their current values
  local vars=(
    "COMPOSESH_OUTPUT_LOCALS"
    "COMPOSESH_DRY_RUN"
    "COMPOSESH_VERBOSE"
    "COMPOSESH_AUTO_BUILD"
    "COMPOSESH_DEFAULT_TAIL_LINES"
    "COMPOSESH_COLOR_OUTPUT"
    "COMPOSESH_GIT_STATUS"
  )
  
  for var in "${vars[@]}"; do
    local value="${!var}"
    local source="(default)"
    
    # Check if var is explicitly set in state file (not a default)
    if grep -q "^${var}=" "$_STATE_FILE" 2>/dev/null; then
      source="(persisted)"
    fi
    
    printf "  %-35s = %-10s %s\n" "$var" "$value" "$source"
  done
  if [[ "$COMPOSESH_SHOW_GIT_STATUS" == "true" ]]; then
    _show_git_branch
  fi
}

_show_git_branch() {
  if which git >/dev/null 2>&1; then
    git status
  fi
}

# Reset all internal state vars for this directory
_reset_state() {
  if [[ -f "$_STATE_FILE" ]]; then
    rm "$_STATE_FILE"
    echo "State reset for: $PWD"
  fi
}

# Helper to apply color if enabled
_colorize() {
  local color_code="$1"
  local text="$2"
  
  if [[ "$COMPOSESH_COLOR_OUTPUT" == "true" ]]; then
    echo -e "${color_code}${text}\033[0m"
  else
    echo "$text"
  fi
}

# ============================================================================
# LOAD PERSISTENT STATE + LOCAL OVERRIDES
# ============================================================================

_load_state

# Load local compose.env if it exists (can override defaults)
[[ -f "$PWD/.compose.env" ]] && source "$PWD/.compose.env"

# Default values for internal state (used on first run)
COMPOSESH_OUTPUT_LOCALS="${COMPOSESH_OUTPUT_LOCALS:-false}"
COMPOSESH_DRY_RUN="${COMPOSESH_DRY_RUN:-false}"
COMPOSESH_VERBOSE="${COMPOSESH_VERBOSE:-false}"
COMPOSESH_AUTO_BUILD="${COMPOSESH_AUTO_BUILD:-false}"
COMPOSESH_DEFAULT_TAIL_LINES="${COMPOSESH_DEFAULT_TAIL_LINES:-200}"
COMPOSESH_COLOR_OUTPUT="${COMPOSESH_COLOR_OUTPUT:-true}"
COMPOSESH_GIT_STATUS="${COMPOSESH_GIT_STATUS:-true}"

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

_run_compose() {
  local cmd="$1"
  shift
  
  if [[ "$COMPOSESH_DRY_RUN" == "true" ]]; then
    _colorize "\033[33m" "[DRY RUN] docker compose -f $COMPOSE_FILE -p $STACK_NAME $cmd $@"
    return 0
  fi
  
  if [[ "$COMPOSESH_VERBOSE" == "true" ]]; then
    _colorize "\033[36m" "[VERBOSE] Running: docker compose -f $COMPOSE_FILE -p $STACK_NAME $cmd $@" >&2
  fi
  
  docker compose -f "$COMPOSE_FILE" -p "$STACK_NAME" "$cmd" "$@"
}

_output_locals() {
  if [[ "$COMPOSESH_OUTPUT_LOCALS" == "true" ]]; then
    cat >&2 << EOF
$(_colorize "\033[35m" "[CONFIG]")
  STACK_NAME=$STACK_NAME
  COMPOSE_FILE=$COMPOSE_FILE
  DRY_RUN=$COMPOSESH_DRY_RUN
  VERBOSE=$COMPOSESH_VERBOSE
  AUTO_BUILD=$COMPOSESH_AUTO_BUILD
  OUTPUT_LOCALS=$COMPOSESH_OUTPUT_LOCALS
  COLOR_OUTPUT=$COMPOSESH_COLOR_OUTPUT
  DEFAULT_TAIL_LINES=$COMPOSESH_DEFAULT_TAIL_LINES
  GIT_STATUS=$GIT_STATUS
EOF
  fi
}

# ============================================================================
# MAIN COMMAND DISPATCH
# ============================================================================

COMPOSE_FILE="${COMPOSE_FILE:-./docker-compose.yml}"
STACK_NAME="${STACK_NAME:-$(basename "$PWD")}"

case "$1" in
  up)
    shift
    [[ "$COMPOSESH_AUTO_BUILD" == "true" ]] && _run_compose "build" --no-cache
    _output_locals
    _run_compose "up" "-d" "$@"
    ;;
  logs)
    shift
    _output_locals
    _run_compose "logs" "-f" "--tail" "$COMPOSESH_DEFAULT_TAIL_LINES" "$@"
    ;;
  down)
    shift
    _output_locals
    _run_compose "down" "$@"
    ;;
  build)
    shift
    _output_locals
    _run_compose "build" "--no-cache" "$@"
    ;;
  ls)
    docker compose ps --services
    ;;
  # ---- Internal state commands ----
  state)
    _show_state
    ;;
  set)
    shift
    if [[ $# -lt 2 ]]; then
      echo "Usage: compose.sh set <VAR> <value>" >&2
      echo "       (VAR can be with or without COMPOSESH_ prefix)" >&2
      return 1
    fi
    _set_internal "$1" "$2"
    _show_state
    ;;
  toggle)
    shift
    if [[ $# -lt 1 ]]; then
      echo "Usage: compose.sh toggle <VAR>" >&2
      echo "       (VAR can be with or without COMPOSESH_ prefix)" >&2
      return 1
    fi
    _toggle_internal "$1"
    ;;
  reset-state)
    _reset_state
    ;;
  # ---- Help/Info ----
  help|--help|-h)
    cat << EOF
compose.sh - Docker Compose wrapper with internal state management
aliased in $HOME/.bash_aliases as compose='$HOME/.local/bin/compose.sh'

USAGE:
  compose.sh <command> [args...]

DOCKER COMPOSE COMMANDS (passed through):
  up [args]         Start containers (auto-builds if AUTO_BUILD=true)
  logs [args]       Follow logs (uses DEFAULT_TAIL_LINES)
  down [args]       Stop containers
  build [args]      Build images
  ls                list service names
  [any command]     Any other docker compose command
  
INTERNAL STATE COMMANDS:
  state             Show all variables (both set and defaults)
  set VAR VALUE     Set internal variable (VAR prefix optional)
  toggle VAR        Toggle boolean variable (VAR prefix optional)
  reset-state       Clear all internal state for this directory

INTERNAL STATE VARIABLES (persist per directory):
  OUTPUT_LOCALS       (true/false) - Show config before running commands
  DRY_RUN             (true/false) - Show commands without executing
  VERBOSE             (true/false) - Show detailed execution info
  AUTO_BUILD          (true/false) - Auto-build on 'up' command
  DEFAULT_TAIL_LINES  (number)    - Log tail size (default: 200)
  COLOR_OUTPUT        (true/false) - Colorize output (default: false)
  GIT_STATUS          (true/false) - show 'git status' output

EXAMPLES:
  # Can use short names (prefix optional):
  compose.sh toggle VERBOSE
  compose.sh toggle COMPOSESH_VERBOSE        # Same as above
  compose.sh set AUTO_BUILD true
  compose.sh set COMPOSESH_AUTO_BUILD true   # Same as above
  
  # With prefix:
  compose.sh set DEFAULT_TAIL_LINES 500
  compose.sh toggle COLOR_OUTPUT

  # Other uses:
  compose.sh up
  compose.sh state                          # Show all vars and their values
  compose.sh logs api                       # Follow logs for 'api' service

NOTES:
  - State persists per directory in: $HOME/.composesh/
  - State files include PWD metadata for identification
  - Local compose.env overrides defaults
  - Variable names can be used with or without COMPOSESH_ prefix
  - All stored vars use COMPOSESH_ prefix internally
  - Colors: yellow (dry-run), cyan (verbose), magenta (config), blue (variable list)

EOF
    ;;
  *)
    _output_locals
    _run_compose "$@"
    ;;
esac
